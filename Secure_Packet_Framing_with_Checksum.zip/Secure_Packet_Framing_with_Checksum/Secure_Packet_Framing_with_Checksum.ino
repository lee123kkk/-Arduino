/*
 * 프로젝트: 안전한 패킷 프레이밍 및 송신 데모
 */
long encoderValue = 12345678;

void setup() {
  Serial.begin(115200);
}

void loop() {
  sendSecurePacket(encoderValue);
  encoderValue += 10;
  delay(50);
}

void sendSecurePacket(long val) {
  byte packet[7];
  
  // 1. 헤더 (고정된 시작 마커)
  packet[0] = 0xFF;
  packet[1] = 0xFE;
  
  // 2. 페이로드 (데이터 분할)
  packet[2] = val & 0xFF;
  packet[3] = (val >> 8) & 0xFF;
  packet[4] = (val >> 16) & 0xFF;
  packet[5] = (val >> 24) & 0xFF;
  
  // 3. 체크섬 (데이터 바이트들의 XOR 연산)
  // 노이즈로 1비트라도 변하면 수신부의 체크섬과 달라져 걸러낼 수 있습니다.
  packet[6] = packet[2] ^ packet[3] ^ packet[4] ^ packet[5];
  
  // 7바이트 패킷 일괄 전송
  Serial.write(packet, 7);
}

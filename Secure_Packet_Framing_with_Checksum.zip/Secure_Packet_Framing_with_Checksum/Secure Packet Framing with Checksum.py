"""
프로젝트: 안전한 패킷 파싱 데모 (Sync & Checksum)
"""
import serial
import time

try:
    ser = serial.Serial('COM7', 115200, timeout=1)
except Exception as e:
    print(f"포트 열기 실패: {e}")
    exit()

def read_secure_packet():
    # 1. 헤더 동기화 (Sync)
    while True:
        # 첫 번째 헤더 탐색
        if ser.read(1) == b'\xFF':
            # 두 번째 헤더 확인
            if ser.read(1) == b'\xFE':
                break # 동기화 성공! 루프 탈출
                
    # 2. 페이로드 및 체크섬 읽기 (총 5바이트)
    data_buffer = ser.read(5)
    
    if len(data_buffer) == 5:
        payload = data_buffer[0:4]
        received_checksum = data_buffer[4]
        
        # 3. 체크섬 검증
        calculated_checksum = payload[0] ^ payload[1] ^ payload[2] ^ payload[3]
        
        if calculated_checksum == received_checksum:
            # 4. 검증 통과 시 데이터 재조립
            encoder_val = int.from_bytes(payload, byteorder='little', signed=True)
            return encoder_val
        else:
            print("❌ [경고] 통신 노이즈 감지: 체크섬 불일치 (패킷 폐기)")
            return None

print("통신 수신 대기 중...")
while True:
    try:
        if ser.in_waiting >= 7:
            value = read_secure_packet()
            if value is not None:
                print(f"✅ 수신된 엔코더 값: {value}")
    except KeyboardInterrupt:
        break

ser.close()

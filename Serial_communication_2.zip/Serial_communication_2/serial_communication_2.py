import serial
import threading
import time

# 포트 설정 (본인 환경에 맞게 수정: 'COM3' 등)
ARDUINO_PORT = 'COM7' 
BAUD_RATE = 115200

def read_and_reassemble(ser):
    """
    아두이노에서 오는 4바이트 데이터를 읽고 재조립하는 스레드 함수
    """
    print("[수신 스레드 시작] 데이터를 기다리는 중...")
    
    while True:
        try:
            # 버퍼에 4바이트 이상 데이터가 쌓였을 때만 읽기
            if ser.in_waiting >= 4:
                # 정확히 4바이트(4 hex data)를 읽어옵니다.
                raw_bytes = ser.read(4)
                
                # 1. 수신한 4바이트를 Hex 형태로 출력 (디버깅용)
                # 예: b'\x12\x34\x56\x78' -> "12 34 56 78"
                hex_str = ' '.join([f'{b:02X}' for b in raw_bytes])
                
                # 2. 4바이트를 다시 4바이트 정수로 재조립
                # byteorder='big' : 아두이노에서 큰 자리수부터 보냈으므로 Big-Endian 설정
                # signed=True : 음수를 포함하는 정수(long) 처리
                reassembled_int = int.from_bytes(raw_bytes, byteorder='big', signed=True)
                
                print(f"수신한 Raw Hex Data: [{hex_str}]  ==>  재조립된 정수: {reassembled_int}")
                
        except Exception as e:
            print(f"통신 에러 또는 스레드 종료: {e}")
            break

def main():
    try:
        # 시리얼 포트 연결
        ser = serial.Serial(ARDUINO_PORT, BAUD_RATE)
        time.sleep(2) # 보드 리셋 대기
        
        # 데이터를 수신할 데몬 스레드 생성 및 시작
        # daemon=True: 메인 프로그램 종료 시 스레드도 함께 종료됨
        rx_thread = threading.Thread(target=read_and_reassemble, args=(ser,), daemon=True)
        rx_thread.start()

        # 메인 스레드는 다른 작업을 할 수 있습니다. 
        # 여기서는 프로그램이 종료되지 않도록 무한 루프를 돌립니다.
        while True:
            time.sleep(1)

    except serial.SerialException:
        print(f"포트 {ARDUINO_PORT}를 열 수 없습니다. 연결 상태를 확인하세요.")
    except KeyboardInterrupt:
        print("\n프로그램을 종료합니다.")
    finally:
        if 'ser' in locals() and ser.is_open:
            ser.close()

if __name__ == '__main__':
    main()
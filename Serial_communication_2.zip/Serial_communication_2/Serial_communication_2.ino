/*
 * 4바이트 정수를 4개의 바이트(Hex)로 쪼개서 전송하는 코드
 */

long myData = 305419896; // 4바이트 정수 (Hex로 변환하면 0x12345678)

void setup() {
  Serial.begin(115200);
}

void loop() {
  // 전송할 4개의 바이트를 담을 배열 생성
  byte hexData[4];

  // 비트 시프트(>>)와 비트 논리곱(&)을 사용하여 4바이트를 1바이트씩 분리
  // 가장 큰 자리(MSB)부터 순서대로 배열에 넣습니다. (Big-Endian 방식)
  hexData[0] = (myData >> 24) & 0xFF; // 최상위 바이트 (0x12)
  hexData[1] = (myData >> 16) & 0xFF; // (0x34)
  hexData[2] = (myData >> 8)  & 0xFF; // (0x56)
  hexData[3] = myData & 0xFF;         // 최하위 바이트 (0x78)

  // 4개의 바이트를 원시 데이터(Raw Bytes) 형태로 시리얼 전송
  Serial.write(hexData, 4);

  // 테스트를 위해 값을 1씩 증가시키고 1초 대기
  myData++;
  delay(1000);
}
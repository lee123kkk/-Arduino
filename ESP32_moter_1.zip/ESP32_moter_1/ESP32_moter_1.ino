// 모터 제어 핀 설정
const int motorA1A = 26; 
const int motorA1B = 27;

void setup() {
  Serial.begin(115200);
  
  // 핀을 출력 모드로 설정
  pinMode(motorA1A, OUTPUT);
  pinMode(motorA1B, OUTPUT);
  
  // 초기 상태는 모터 정지
  digitalWrite(motorA1A, LOW);
  digitalWrite(motorA1B, LOW);
  
  Serial.println("ESP32 Motor Control Ready. Waiting for commands...");
}

void loop() {
  if (Serial.available() > 0) {
    String command = Serial.readStringUntil('\n'); 
    command.trim(); 

    if (command == "F") {
      // 전진 (한 쪽은 HIGH, 다른 쪽은 LOW)
      digitalWrite(motorA1A, HIGH);
      digitalWrite(motorA1B, LOW);
      Serial.println("Action: Motor FORWARD");
    } 
    else if (command == "B") {
      // 후진 (반대로 신호 주기)
      digitalWrite(motorA1A, LOW);
      digitalWrite(motorA1B, HIGH);
      Serial.println("Action: Motor BACKWARD");
    } 
    else if (command == "S") {
      // 정지 (둘 다 LOW)
      digitalWrite(motorA1A, LOW);
      digitalWrite(motorA1B, LOW);
      Serial.println("Action: Motor STOP");
    } 
    else {
      Serial.println("Unknown Command. Use F, B, or S.");
    }
  }
}
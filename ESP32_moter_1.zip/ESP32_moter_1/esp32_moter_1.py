import serial
import time

# 포트 번호는 이전과 동일한 포트로 맞춰주세요 (예: 'COM8')
port = 'COM8' 
baudrate = 115200

print(f"{port} 포트 연결을 시도합니다...")
ser = serial.Serial(port, baudrate, timeout=1)
time.sleep(2) 

print("연결 성공! 모터 제어를 시작합니다.")
print("명령어 안내: [F]전진, [B]후진, [S]정지, [Q]종료")
print("-" * 40)

def send_command(cmd):
    ser.write((cmd + '\n').encode('utf-8'))
    time.sleep(0.1) 
    if ser.in_waiting > 0:
        response = ser.readline().decode('utf-8').strip()
        print(f"[ESP32 응답] {response}")

try:
    while True:
        user_input = input("명령어 (F/B/S/Q) : ").strip().upper()
        
        if user_input == 'Q':
            # 종료하기 전에 안전하게 모터를 먼저 정지시킵니다.
            send_command('S')
            print("프로그램을 종료합니다.")
            break
            
        if user_input in ['F', 'B', 'S']:
            send_command(user_input)
        else:
            print("잘못된 입력입니다. F, B, S 중 하나를 입력하세요.")

except KeyboardInterrupt:
    send_command('S')
    print("\n강제 종료됨")

finally:
    ser.close()
    print("시리얼 포트를 닫았습니다.")
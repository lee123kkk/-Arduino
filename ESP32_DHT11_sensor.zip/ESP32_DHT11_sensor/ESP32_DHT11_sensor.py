import serial
import time

# 포트 번호는 기존에 사용하시던 COM8을 유지합니다.
port = 'COM8' 
baudrate = 115200

print(f"{port} 포트 연결을 시도합니다...")
try:
    ser = serial.Serial(port, baudrate, timeout=1)
    time.sleep(2) # 연결 후 ESP32 부팅 대기
    print("연결 성공! 온습도 데이터를 읽기 시작합니다.")
    print("-" * 40)
except serial.SerialException as e:
    print(f"연결 실패: {e}")
    exit()

def parse_sensor_data(line):
    # 전송받은 문자열 예시: "T:25.50,H:60.00"
    try:
        if "T:" in line and "H:" in line:
            # 쉼표(,)를 기준으로 나누기
            parts = line.split(',')
            
            # 각각의 값 추출하기
            temp_str = parts[0].replace("T:", "")
            hum_str = parts[1].replace("H:", "")
            
            # 실수(float)로 변환
            temperature = float(temp_str)
            humidity = float(hum_str)
            
            print(f"[ESP32] 현재 온도: {temperature:05.2f}°C  |  현재 습도: {humidity:05.2f}%")
        else:
            # 센서 오류 메시지나 초기 부팅 메시지 출력
            print(f"[메시지] {line}")
            
    except Exception as e:
        print(f"데이터 파싱 오류: {line} ({e})")

try:
    while True:
        # 시리얼 포트에서 한 줄(엔터까지) 읽기
        if ser.in_waiting > 0:
            line = ser.readline().decode('utf-8', errors='ignore').strip()
            if line:
                parse_sensor_data(line)
                
        time.sleep(0.1)

except KeyboardInterrupt:
    print("\n강제 종료됨")

finally:
    if 'ser' in locals() and ser.is_open:
        ser.close()
    print("시리얼 포트를 닫았습니다.")
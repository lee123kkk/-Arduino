#include <DHT.h>

// DHT 센서 설정
#define DHTPIN 4       // DHT11 DATA 핀을 ESP32의 D4에 연결
#define DHTTYPE DHT11  // 사용하는 센서 종류 지정

DHT dht(DHTPIN, DHTTYPE);

void setup() {
  Serial.begin(115200);
  dht.begin();
  
  Serial.println("ESP32 DHT11 Sensor Ready.");
}

void loop() {
  // DHT11 센서는 데이터를 읽는 데 최소 2초의 간격이 필요합니다.
  delay(2000);

  // 습도 읽기
  float h = dht.readHumidity();
  // 온도 읽기 (섭씨)
  float t = dht.readTemperature();

  // 값 읽기에 실패했는지 확인
  if (isnan(h) || isnan(t)) {
    Serial.println("Failed to read from DHT sensor!");
    return;
  }

  // 데스크톱(파이썬)에서 파싱하기 쉽게 [T:온도,H:습도] 형태로 전송
  Serial.print("T:");
  Serial.print(t);
  Serial.print(",H:");
  Serial.println(h);
}
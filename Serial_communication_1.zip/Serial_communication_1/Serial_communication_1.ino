const int ledPin = 8;
const int buttonPin = 2;

int lastButtonState = HIGH;

void setup() {
  // 파이썬과 동일한 통신 속도(Baud Rate) 설정
  Serial.begin(115200); 
  
  pinMode(ledPin, OUTPUT);
  pinMode(buttonPin, INPUT_PULLUP); // 내부 풀업 저항 사용
}

void loop() {
  // 1. 파이썬 -> 아두이노 (수신)
  if (Serial.available() > 0) {
    char receivedChar = Serial.read(); // 1바이트 읽기
    
    if (receivedChar == '1') {
      digitalWrite(ledPin, HIGH); // LED 켜기
      Serial.println("Arduino: LED is ON"); // 파이썬으로 확인 메시지 전송
    } 
    else if (receivedChar == '0') {
      digitalWrite(ledPin, LOW);  // LED 끄기
      Serial.println("Arduino: LED is OFF");
    }
  }

  // 2. 아두이노 -> 파이썬 (송신)
  int currentButtonState = digitalRead(buttonPin);
  
  // 버튼이 눌리는 순간 감지 (HIGH -> LOW)
  if (lastButtonState == HIGH && currentButtonState == LOW) {
    delay(50); // 디바운싱 (기계적 떨림 방지)
    if (digitalRead(buttonPin) == LOW) {
      Serial.println("Arduino: Button Pressed!"); // 파이썬으로 데이터 전송
    }
  }
  lastButtonState = currentButtonState;
}
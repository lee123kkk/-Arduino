import serial
import time
import threading

# 아두이노 포트 설정 (본인의 포트에 맞게 수정하세요. 예: 'COM3', '/dev/ttyACM0')
ARDUINO_PORT = 'COM7' 
BAUD_RATE = 115200

# 아두이노에서 오는 데이터를 계속 읽어들이는 함수 (서브 스레드용)
def read_from_arduino(ser):
    while True:
        try:
            if ser.in_waiting > 0:
                # 데이터를 읽고 디코딩하여 출력
                line = ser.readline().decode('utf-8').rstrip()
                print(f"\n[수신] {line}")
                print("명령 입력 (1: 켜기, 0: 끄기, q: 종료) >> ", end="", flush=True)
        except:
            break

def main():
    try:
        # 시리얼 포트 연결
        ser = serial.Serial(ARDUINO_PORT, BAUD_RATE, timeout=1)
        time.sleep(2) # 아두이노가 리셋되고 준비될 때까지 2초 대기 (필수)
        print(f"[{ARDUINO_PORT}] 아두이노와 연결되었습니다.")
        
        # 수신 스레드 시작
        read_thread = threading.Thread(target=read_from_arduino, args=(ser,), daemon=True)
        read_thread.start()

        # 메인 루프: 사용자 입력 받아서 아두이노로 송신
        while True:
            cmd = input("명령 입력 (1: 켜기, 0: 끄기, q: 종료) >> ")
            
            if cmd == 'q':
                print("프로그램을 종료합니다.")
                break
            elif cmd in ['1', '0']:
                # 문자를 바이트(utf-8)로 변환하여 전송
                ser.write(cmd.encode('utf-8'))
            else:
                print("잘못된 입력입니다.")

    except serial.SerialException:
        print(f"오류: {ARDUINO_PORT} 포트를 열 수 없습니다. 포트 번호와 사용 여부를 확인하세요.")
    finally:
        if 'ser' in locals() and ser.is_open:
            ser.close()

if __name__ == '__main__':
    main()
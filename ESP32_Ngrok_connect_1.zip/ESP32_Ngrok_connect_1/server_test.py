# 간단한 서버 코드 (8080 포트 사용)
from http.server import HTTPServer, BaseHTTPRequestHandler

class SimpleHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/plain')
        self.end_headers()
        self.wfile.write(b"Hello! This is Desktop Server.")

print("Server is running on port 8080...")
httpd = HTTPServer(('0.0.0.0', 8080), SimpleHandler)
httpd.serve_forever()
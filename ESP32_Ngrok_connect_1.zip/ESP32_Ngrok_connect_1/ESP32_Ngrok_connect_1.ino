#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>

// 1. ESP32가 접속할 주변 와이파이 정보 (스마트폰 핫스팟 등)
const char* ssid = "asia-edu_2G";
const char* password = "12345678";

// 2. Ngrok 주소 (스크린샷에 뜬 본인의 주소를 넣으세요)
const char* serverName = "https://hematal-rosalyn-unadmittedly.ngrok-free.dev";

void setup() {
  Serial.begin(115200);

  // 와이파이 연결 시작
  WiFi.begin(ssid, password);
  Serial.println("Connecting to WiFi...");
  
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  
  Serial.println("");
  Serial.print("Connected to WiFi network with IP Address: ");
  Serial.println(WiFi.localIP());
}

void loop() {
  // 와이파이가 연결된 상태일 때만 실행
  if(WiFi.status()== WL_CONNECTED){
    // HTTPS 접속을 위한 보안 클라이언트 선언
    WiFiClientSecure client;
    client.setInsecure(); // 중요: 인증서 검사를 하지 않음 (테스트용)

    HTTPClient http;

    // 서버 주소 설정
    http.begin(client, serverName);

    // [중요] Ngrok의 브라우저 경고 페이지를 건너뛰기 위한 헤더 추가
    http.addHeader("ngrok-skip-browser-warning", "1");

    // GET 요청 보내기
    int httpResponseCode = http.GET();
    
    if (httpResponseCode > 0) {
      Serial.print("HTTP Response code: ");
      Serial.println(httpResponseCode);
      String payload = http.getString();
      Serial.println("Response from server: " + payload);
    }
    else {
      Serial.print("Error code: ");
      Serial.println(httpResponseCode);
    }
    // 자원 해제
    http.end();
  }
  else {
    Serial.println("WiFi Disconnected");
  }

  // 5초마다 한 번씩 데이터를 보냅니다
  delay(5000);
}